import { Directive, ElementRef, EnvironmentInjector, Injectable, Input, afterNextRender, inject } from '@angular/core';
import { NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';
import { HalvoService } from '@halvo/angular';
import * as i0 from "@angular/core";
/** Links whose order defines "forward" and "back" between pages. */
const NAV_LINKS = '.snav a[href], .tabbar a[href], .side a[href], nav a[href]';
/** Longest a page may wait for its exit animation before the navigation goes on anyway. */
const MAX_WAIT_MS = 400;
/**
 * Runs Halvo's page swap between routes: the old page's cards sink and the page slides out,
 * then the new page slides in from the side it comes from and its cards rise.
 * Set up with `HalvoRouteTransitionDirective` on the element around `<router-outlet>`, and
 * `withHalvoTransitions(routes)` in `provideRouter` for the exit half.
 */
export class HalvoRouteTransitions {
    constructor() {
        this.halvo = inject(HalvoService);
        this.router = inject(Router);
        this.injector = inject(EnvironmentInjector);
        this.container = null;
        this.depth = 1;
        this.cards = true;
        this.direction = 1;
        this.from = '';
        this.leaving = null;
    }
    /** Called by the directive. */
    attach(el, depth, cards) {
        this.container = el;
        this.depth = Math.max(1, depth);
        this.cards = cards;
        if (this.sub || !this.halvo.isBrowser)
            return;
        this.sub = this.router.events.subscribe((e) => {
            if (e instanceof NavigationStart) {
                this.from = this.router.url;
                this.direction = this.dirBetween(this.from, e.url, e.navigationTrigger === 'popstate');
            }
            else if (e instanceof NavigationEnd) {
                const changed = this.key(this.from) !== this.key(e.urlAfterRedirects);
                const left = this.leaving !== null;
                this.leaving = null;
                if (changed || left)
                    this.enterAfterRender();
            }
            else if (e instanceof NavigationCancel || e instanceof NavigationError) {
                if (this.leaving && this.container) {
                    const c = this.container;
                    this.halvo.run((h) => h.motion.pageReset(c));
                }
                this.leaving = null;
            }
        });
    }
    /** Called by the directive. */
    detach(el) {
        if (this.container === el)
            this.container = null;
    }
    /**
     * Plays the exit animation when the page (the first `transitionDepth` URL segments) changes.
     * Used by `halvoLeaveGuard`; resolves true when it's done (at most 400ms).
     */
    leave(fromUrl, toUrl) {
        const c = this.container;
        if (!c || !this.halvo.motion || this.key(fromUrl) === this.key(toUrl))
            return true;
        if (this.leaving?.url === toUrl)
            return this.leaving.done;
        const dir = this.direction;
        const run = this.halvo.run((h) => h.motion.pageOut(c, { direction: dir })) ?? Promise.resolve();
        const done = Promise.race([run, new Promise((r) => setTimeout(r, MAX_WAIT_MS))]).then(() => true);
        this.leaving = { url: toUrl, done };
        return done;
    }
    enterAfterRender() {
        const c = this.container;
        if (!c)
            return;
        const dir = this.direction;
        const cards = this.cards;
        afterNextRender(() => this.halvo.run((h) => h.motion.pageIn(c, { direction: dir, cards })), { injector: this.injector });
    }
    /** The page a URL belongs to: its first `depth` path segments. */
    key(url) {
        return url.split(/[?#(]/)[0].split('/').filter(Boolean).slice(0, this.depth).join('/');
    }
    dirBetween(from, to, popstate) {
        const keys = [];
        document.querySelectorAll(NAV_LINKS).forEach((a) => {
            const k = this.key(new URL(a.href, document.baseURI).pathname.replace(new URL(document.baseURI).pathname, '/'));
            if (!keys.includes(k))
                keys.push(k);
        });
        const a = keys.indexOf(this.key(from));
        const b = keys.indexOf(this.key(to));
        if (a > -1 && b > -1 && a !== b)
            return b > a ? 1 : -1;
        return popstate ? -1 : 1;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitions, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitions, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitions, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Marks the element that holds `<router-outlet>` as the page container for Halvo's page swap.
 * The new page always slides in and its cards rise; add `withHalvoTransitions(routes)` for the exit half.
 *
 *   <main halvoRouteTransition><router-outlet /></main>
 */
export class HalvoRouteTransitionDirective {
    constructor() {
        /** How many URL segments name a page (default 1: /rooms/living → /rooms/kitchen is not a page change). */
        this.transitionDepth = 1;
        /** Let the transition rise the new page's cards (set false if pages run halvoMotion themselves). */
        this.transitionCards = true;
        this.el = inject(ElementRef);
        this.transitions = inject(HalvoRouteTransitions);
    }
    ngOnInit() {
        this.transitions.attach(this.el.nativeElement, this.transitionDepth, this.transitionCards);
    }
    ngOnDestroy() {
        this.transitions.detach(this.el.nativeElement);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoRouteTransitionDirective, isStandalone: true, selector: "[halvoRouteTransition]", inputs: { transitionDepth: "transitionDepth", transitionCards: "transitionCards" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoRouteTransition]',
                    standalone: true,
                }]
        }], propDecorators: { transitionDepth: [{
                type: Input
            }], transitionCards: [{
                type: Input
            }] } });
/** Holds a route's page on screen while Halvo plays its exit animation (≤ 400ms). */
export const halvoLeaveGuard = (_component, _route, current, next) => inject(HalvoRouteTransitions).leave(current.url, next.url);
/**
 * Adds `halvoLeaveGuard` to every route that renders a component, recursively.
 *
 *   provideRouter(withHalvoTransitions(routes))
 *
 * Wrap lazily loaded child route arrays (`loadChildren`) the same way.
 */
export function withHalvoTransitions(routes) {
    return routes.map((r) => {
        const out = { ...r };
        if (r.component || r.loadComponent)
            out.canDeactivate = [...(r.canDeactivate ?? []), halvoLeaveGuard];
        if (r.children)
            out.children = withHalvoTransitions(r.children);
        return out;
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUtdHJhbnNpdGlvbnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9yb3V0ZXIvc3JjL3JvdXRlLXRyYW5zaXRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQXFCLGVBQWUsRUFBRSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUksT0FBTyxFQUFtQixnQkFBZ0IsRUFBRSxhQUFhLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBUyxNQUFNLEVBQVUsTUFBTSxpQkFBaUIsQ0FBQztBQUU1SSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7O0FBRTlDLG9FQUFvRTtBQUNwRSxNQUFNLFNBQVMsR0FBRyw0REFBNEQsQ0FBQztBQUMvRSwyRkFBMkY7QUFDM0YsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDO0FBRXhCOzs7OztHQUtHO0FBRUgsTUFBTSxPQUFPLHFCQUFxQjtJQURsQztRQUVtQixVQUFLLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdCLFdBQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDeEIsYUFBUSxHQUFHLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ2hELGNBQVMsR0FBdUIsSUFBSSxDQUFDO1FBQ3JDLFVBQUssR0FBRyxDQUFDLENBQUM7UUFDVixVQUFLLEdBQUcsSUFBSSxDQUFDO1FBRWIsY0FBUyxHQUFXLENBQUMsQ0FBQztRQUN0QixTQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ1YsWUFBTyxHQUFtRCxJQUFJLENBQUM7S0F1RXhFO0lBckVDLCtCQUErQjtJQUMvQixNQUFNLENBQUMsRUFBZSxFQUFFLEtBQWEsRUFBRSxLQUFjO1FBQ25ELElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTO1lBQUUsT0FBTztRQUM5QyxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQzVDLElBQUksQ0FBQyxZQUFZLGVBQWUsRUFBRSxDQUFDO2dCQUNqQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2dCQUM1QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsS0FBSyxVQUFVLENBQUMsQ0FBQztZQUN6RixDQUFDO2lCQUFNLElBQUksQ0FBQyxZQUFZLGFBQWEsRUFBRSxDQUFDO2dCQUN0QyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO2dCQUN0RSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxLQUFLLElBQUksQ0FBQztnQkFDbkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0JBQ3BCLElBQUksT0FBTyxJQUFJLElBQUk7b0JBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDL0MsQ0FBQztpQkFBTSxJQUFJLENBQUMsWUFBWSxnQkFBZ0IsSUFBSSxDQUFDLFlBQVksZUFBZSxFQUFFLENBQUM7Z0JBQ3pFLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ25DLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7b0JBQ3pCLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMvQyxDQUFDO2dCQUNELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQ3RCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCwrQkFBK0I7SUFDL0IsTUFBTSxDQUFDLEVBQWU7UUFDcEIsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLEVBQUU7WUFBRSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztJQUNuRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsS0FBSyxDQUFDLE9BQWUsRUFBRSxLQUFhO1FBQ2xDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDekIsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7WUFBRSxPQUFPLElBQUksQ0FBQztRQUNuRixJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxLQUFLLEtBQUs7WUFBRSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO1FBQzFELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDM0IsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2hHLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxPQUFPLENBQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hHLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ3BDLE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVPLGdCQUFnQjtRQUN0QixNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxDQUFDO1lBQUUsT0FBTztRQUNmLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDM0IsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN6QixlQUFlLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQzNILENBQUM7SUFFRCxrRUFBa0U7SUFDMUQsR0FBRyxDQUFDLEdBQVc7UUFDckIsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3pGLENBQUM7SUFFTyxVQUFVLENBQUMsSUFBWSxFQUFFLEVBQVUsRUFBRSxRQUFpQjtRQUM1RCxNQUFNLElBQUksR0FBYSxFQUFFLENBQUM7UUFDMUIsUUFBUSxDQUFDLGdCQUFnQixDQUFvQixTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNwRSxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ2hILElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDdkMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzNCLENBQUM7K0dBaEZVLHFCQUFxQjttSEFBckIscUJBQXFCLGNBRFIsTUFBTTs7NEZBQ25CLHFCQUFxQjtrQkFEakMsVUFBVTttQkFBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUU7O0FBb0ZsQzs7Ozs7R0FLRztBQUtILE1BQU0sT0FBTyw2QkFBNkI7SUFKMUM7UUFLRSwwR0FBMEc7UUFDakcsb0JBQWUsR0FBRyxDQUFDLENBQUM7UUFDN0Isb0dBQW9HO1FBQzNGLG9CQUFlLEdBQUcsSUFBSSxDQUFDO1FBRWYsT0FBRSxHQUFHLE1BQU0sQ0FBMEIsVUFBVSxDQUFDLENBQUM7UUFDakQsZ0JBQVcsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUMsQ0FBQztLQVM5RDtJQVBDLFFBQVE7UUFDTixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUM3RixDQUFDO0lBRUQsV0FBVztRQUNULElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDakQsQ0FBQzsrR0FmVSw2QkFBNkI7bUdBQTdCLDZCQUE2Qjs7NEZBQTdCLDZCQUE2QjtrQkFKekMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsd0JBQXdCO29CQUNsQyxVQUFVLEVBQUUsSUFBSTtpQkFDakI7OEJBR1UsZUFBZTtzQkFBdkIsS0FBSztnQkFFRyxlQUFlO3NCQUF2QixLQUFLOztBQWNSLHFGQUFxRjtBQUNyRixNQUFNLENBQUMsTUFBTSxlQUFlLEdBQTZCLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FDN0YsTUFBTSxDQUFDLHFCQUFxQixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBRTdEOzs7Ozs7R0FNRztBQUNILE1BQU0sVUFBVSxvQkFBb0IsQ0FBQyxNQUFjO0lBQ2pELE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO1FBQ3RCLE1BQU0sR0FBRyxHQUFVLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLGFBQWE7WUFBRSxHQUFHLENBQUMsYUFBYSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDdEcsSUFBSSxDQUFDLENBQUMsUUFBUTtZQUFFLEdBQUcsQ0FBQyxRQUFRLEdBQUcsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2hFLE9BQU8sR0FBRyxDQUFDO0lBQ2IsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBFbGVtZW50UmVmLCBFbnZpcm9ubWVudEluamVjdG9yLCBJbmplY3RhYmxlLCBJbnB1dCwgT25EZXN0cm95LCBPbkluaXQsIGFmdGVyTmV4dFJlbmRlciwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDYW5EZWFjdGl2YXRlRm4sIE5hdmlnYXRpb25DYW5jZWwsIE5hdmlnYXRpb25FbmQsIE5hdmlnYXRpb25FcnJvciwgTmF2aWdhdGlvblN0YXJ0LCBSb3V0ZSwgUm91dGVyLCBSb3V0ZXMgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBIYWx2b1NlcnZpY2UgfSBmcm9tICdAaGFsdm8vYW5ndWxhcic7XG5cbi8qKiBMaW5rcyB3aG9zZSBvcmRlciBkZWZpbmVzIFwiZm9yd2FyZFwiIGFuZCBcImJhY2tcIiBiZXR3ZWVuIHBhZ2VzLiAqL1xuY29uc3QgTkFWX0xJTktTID0gJy5zbmF2IGFbaHJlZl0sIC50YWJiYXIgYVtocmVmXSwgLnNpZGUgYVtocmVmXSwgbmF2IGFbaHJlZl0nO1xuLyoqIExvbmdlc3QgYSBwYWdlIG1heSB3YWl0IGZvciBpdHMgZXhpdCBhbmltYXRpb24gYmVmb3JlIHRoZSBuYXZpZ2F0aW9uIGdvZXMgb24gYW55d2F5LiAqL1xuY29uc3QgTUFYX1dBSVRfTVMgPSA0MDA7XG5cbi8qKlxuICogUnVucyBIYWx2bydzIHBhZ2Ugc3dhcCBiZXR3ZWVuIHJvdXRlczogdGhlIG9sZCBwYWdlJ3MgY2FyZHMgc2luayBhbmQgdGhlIHBhZ2Ugc2xpZGVzIG91dCxcbiAqIHRoZW4gdGhlIG5ldyBwYWdlIHNsaWRlcyBpbiBmcm9tIHRoZSBzaWRlIGl0IGNvbWVzIGZyb20gYW5kIGl0cyBjYXJkcyByaXNlLlxuICogU2V0IHVwIHdpdGggYEhhbHZvUm91dGVUcmFuc2l0aW9uRGlyZWN0aXZlYCBvbiB0aGUgZWxlbWVudCBhcm91bmQgYDxyb3V0ZXItb3V0bGV0PmAsIGFuZFxuICogYHdpdGhIYWx2b1RyYW5zaXRpb25zKHJvdXRlcylgIGluIGBwcm92aWRlUm91dGVyYCBmb3IgdGhlIGV4aXQgaGFsZi5cbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBIYWx2b1JvdXRlVHJhbnNpdGlvbnMge1xuICBwcml2YXRlIHJlYWRvbmx5IGhhbHZvID0gaW5qZWN0KEhhbHZvU2VydmljZSk7XG4gIHByaXZhdGUgcmVhZG9ubHkgcm91dGVyID0gaW5qZWN0KFJvdXRlcik7XG4gIHByaXZhdGUgcmVhZG9ubHkgaW5qZWN0b3IgPSBpbmplY3QoRW52aXJvbm1lbnRJbmplY3Rvcik7XG4gIHByaXZhdGUgY29udGFpbmVyOiBIVE1MRWxlbWVudCB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIGRlcHRoID0gMTtcbiAgcHJpdmF0ZSBjYXJkcyA9IHRydWU7XG4gIHByaXZhdGUgc3ViPzogU3Vic2NyaXB0aW9uO1xuICBwcml2YXRlIGRpcmVjdGlvbjogMSB8IC0xID0gMTtcbiAgcHJpdmF0ZSBmcm9tID0gJyc7XG4gIHByaXZhdGUgbGVhdmluZzogeyB1cmw6IHN0cmluZzsgZG9uZTogUHJvbWlzZTxib29sZWFuPiB9IHwgbnVsbCA9IG51bGw7XG5cbiAgLyoqIENhbGxlZCBieSB0aGUgZGlyZWN0aXZlLiAqL1xuICBhdHRhY2goZWw6IEhUTUxFbGVtZW50LCBkZXB0aDogbnVtYmVyLCBjYXJkczogYm9vbGVhbik6IHZvaWQge1xuICAgIHRoaXMuY29udGFpbmVyID0gZWw7XG4gICAgdGhpcy5kZXB0aCA9IE1hdGgubWF4KDEsIGRlcHRoKTtcbiAgICB0aGlzLmNhcmRzID0gY2FyZHM7XG4gICAgaWYgKHRoaXMuc3ViIHx8ICF0aGlzLmhhbHZvLmlzQnJvd3NlcikgcmV0dXJuO1xuICAgIHRoaXMuc3ViID0gdGhpcy5yb3V0ZXIuZXZlbnRzLnN1YnNjcmliZSgoZSkgPT4ge1xuICAgICAgaWYgKGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uU3RhcnQpIHtcbiAgICAgICAgdGhpcy5mcm9tID0gdGhpcy5yb3V0ZXIudXJsO1xuICAgICAgICB0aGlzLmRpcmVjdGlvbiA9IHRoaXMuZGlyQmV0d2Vlbih0aGlzLmZyb20sIGUudXJsLCBlLm5hdmlnYXRpb25UcmlnZ2VyID09PSAncG9wc3RhdGUnKTtcbiAgICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcbiAgICAgICAgY29uc3QgY2hhbmdlZCA9IHRoaXMua2V5KHRoaXMuZnJvbSkgIT09IHRoaXMua2V5KGUudXJsQWZ0ZXJSZWRpcmVjdHMpO1xuICAgICAgICBjb25zdCBsZWZ0ID0gdGhpcy5sZWF2aW5nICE9PSBudWxsO1xuICAgICAgICB0aGlzLmxlYXZpbmcgPSBudWxsO1xuICAgICAgICBpZiAoY2hhbmdlZCB8fCBsZWZ0KSB0aGlzLmVudGVyQWZ0ZXJSZW5kZXIoKTtcbiAgICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25DYW5jZWwgfHwgZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FcnJvcikge1xuICAgICAgICBpZiAodGhpcy5sZWF2aW5nICYmIHRoaXMuY29udGFpbmVyKSB7XG4gICAgICAgICAgY29uc3QgYyA9IHRoaXMuY29udGFpbmVyO1xuICAgICAgICAgIHRoaXMuaGFsdm8ucnVuKChoKSA9PiBoLm1vdGlvbi5wYWdlUmVzZXQoYykpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubGVhdmluZyA9IG51bGw7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKiogQ2FsbGVkIGJ5IHRoZSBkaXJlY3RpdmUuICovXG4gIGRldGFjaChlbDogSFRNTEVsZW1lbnQpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5jb250YWluZXIgPT09IGVsKSB0aGlzLmNvbnRhaW5lciA9IG51bGw7XG4gIH1cblxuICAvKipcbiAgICogUGxheXMgdGhlIGV4aXQgYW5pbWF0aW9uIHdoZW4gdGhlIHBhZ2UgKHRoZSBmaXJzdCBgdHJhbnNpdGlvbkRlcHRoYCBVUkwgc2VnbWVudHMpIGNoYW5nZXMuXG4gICAqIFVzZWQgYnkgYGhhbHZvTGVhdmVHdWFyZGA7IHJlc29sdmVzIHRydWUgd2hlbiBpdCdzIGRvbmUgKGF0IG1vc3QgNDAwbXMpLlxuICAgKi9cbiAgbGVhdmUoZnJvbVVybDogc3RyaW5nLCB0b1VybDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB8IGJvb2xlYW4ge1xuICAgIGNvbnN0IGMgPSB0aGlzLmNvbnRhaW5lcjtcbiAgICBpZiAoIWMgfHwgIXRoaXMuaGFsdm8ubW90aW9uIHx8IHRoaXMua2V5KGZyb21VcmwpID09PSB0aGlzLmtleSh0b1VybCkpIHJldHVybiB0cnVlO1xuICAgIGlmICh0aGlzLmxlYXZpbmc/LnVybCA9PT0gdG9VcmwpIHJldHVybiB0aGlzLmxlYXZpbmcuZG9uZTtcbiAgICBjb25zdCBkaXIgPSB0aGlzLmRpcmVjdGlvbjtcbiAgICBjb25zdCBydW4gPSB0aGlzLmhhbHZvLnJ1bigoaCkgPT4gaC5tb3Rpb24ucGFnZU91dChjLCB7IGRpcmVjdGlvbjogZGlyIH0pKSA/PyBQcm9taXNlLnJlc29sdmUoKTtcbiAgICBjb25zdCBkb25lID0gUHJvbWlzZS5yYWNlKFtydW4sIG5ldyBQcm9taXNlPHZvaWQ+KChyKSA9PiBzZXRUaW1lb3V0KHIsIE1BWF9XQUlUX01TKSldKS50aGVuKCgpID0+IHRydWUpO1xuICAgIHRoaXMubGVhdmluZyA9IHsgdXJsOiB0b1VybCwgZG9uZSB9O1xuICAgIHJldHVybiBkb25lO1xuICB9XG5cbiAgcHJpdmF0ZSBlbnRlckFmdGVyUmVuZGVyKCk6IHZvaWQge1xuICAgIGNvbnN0IGMgPSB0aGlzLmNvbnRhaW5lcjtcbiAgICBpZiAoIWMpIHJldHVybjtcbiAgICBjb25zdCBkaXIgPSB0aGlzLmRpcmVjdGlvbjtcbiAgICBjb25zdCBjYXJkcyA9IHRoaXMuY2FyZHM7XG4gICAgYWZ0ZXJOZXh0UmVuZGVyKCgpID0+IHRoaXMuaGFsdm8ucnVuKChoKSA9PiBoLm1vdGlvbi5wYWdlSW4oYywgeyBkaXJlY3Rpb246IGRpciwgY2FyZHMgfSkpLCB7IGluamVjdG9yOiB0aGlzLmluamVjdG9yIH0pO1xuICB9XG5cbiAgLyoqIFRoZSBwYWdlIGEgVVJMIGJlbG9uZ3MgdG86IGl0cyBmaXJzdCBgZGVwdGhgIHBhdGggc2VnbWVudHMuICovXG4gIHByaXZhdGUga2V5KHVybDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdXJsLnNwbGl0KC9bPyMoXS8pWzBdLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pLnNsaWNlKDAsIHRoaXMuZGVwdGgpLmpvaW4oJy8nKTtcbiAgfVxuXG4gIHByaXZhdGUgZGlyQmV0d2Vlbihmcm9tOiBzdHJpbmcsIHRvOiBzdHJpbmcsIHBvcHN0YXRlOiBib29sZWFuKTogMSB8IC0xIHtcbiAgICBjb25zdCBrZXlzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEFuY2hvckVsZW1lbnQ+KE5BVl9MSU5LUykuZm9yRWFjaCgoYSkgPT4ge1xuICAgICAgY29uc3QgayA9IHRoaXMua2V5KG5ldyBVUkwoYS5ocmVmLCBkb2N1bWVudC5iYXNlVVJJKS5wYXRobmFtZS5yZXBsYWNlKG5ldyBVUkwoZG9jdW1lbnQuYmFzZVVSSSkucGF0aG5hbWUsICcvJykpO1xuICAgICAgaWYgKCFrZXlzLmluY2x1ZGVzKGspKSBrZXlzLnB1c2goayk7XG4gICAgfSk7XG4gICAgY29uc3QgYSA9IGtleXMuaW5kZXhPZih0aGlzLmtleShmcm9tKSk7XG4gICAgY29uc3QgYiA9IGtleXMuaW5kZXhPZih0aGlzLmtleSh0bykpO1xuICAgIGlmIChhID4gLTEgJiYgYiA+IC0xICYmIGEgIT09IGIpIHJldHVybiBiID4gYSA/IDEgOiAtMTtcbiAgICByZXR1cm4gcG9wc3RhdGUgPyAtMSA6IDE7XG4gIH1cbn1cblxuLyoqXG4gKiBNYXJrcyB0aGUgZWxlbWVudCB0aGF0IGhvbGRzIGA8cm91dGVyLW91dGxldD5gIGFzIHRoZSBwYWdlIGNvbnRhaW5lciBmb3IgSGFsdm8ncyBwYWdlIHN3YXAuXG4gKiBUaGUgbmV3IHBhZ2UgYWx3YXlzIHNsaWRlcyBpbiBhbmQgaXRzIGNhcmRzIHJpc2U7IGFkZCBgd2l0aEhhbHZvVHJhbnNpdGlvbnMocm91dGVzKWAgZm9yIHRoZSBleGl0IGhhbGYuXG4gKlxuICogICA8bWFpbiBoYWx2b1JvdXRlVHJhbnNpdGlvbj48cm91dGVyLW91dGxldCAvPjwvbWFpbj5cbiAqL1xuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW2hhbHZvUm91dGVUcmFuc2l0aW9uXScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIEhhbHZvUm91dGVUcmFuc2l0aW9uRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAvKiogSG93IG1hbnkgVVJMIHNlZ21lbnRzIG5hbWUgYSBwYWdlIChkZWZhdWx0IDE6IC9yb29tcy9saXZpbmcg4oaSIC9yb29tcy9raXRjaGVuIGlzIG5vdCBhIHBhZ2UgY2hhbmdlKS4gKi9cbiAgQElucHV0KCkgdHJhbnNpdGlvbkRlcHRoID0gMTtcbiAgLyoqIExldCB0aGUgdHJhbnNpdGlvbiByaXNlIHRoZSBuZXcgcGFnZSdzIGNhcmRzIChzZXQgZmFsc2UgaWYgcGFnZXMgcnVuIGhhbHZvTW90aW9uIHRoZW1zZWx2ZXMpLiAqL1xuICBASW5wdXQoKSB0cmFuc2l0aW9uQ2FyZHMgPSB0cnVlO1xuXG4gIHByaXZhdGUgcmVhZG9ubHkgZWwgPSBpbmplY3Q8RWxlbWVudFJlZjxIVE1MRWxlbWVudD4+KEVsZW1lbnRSZWYpO1xuICBwcml2YXRlIHJlYWRvbmx5IHRyYW5zaXRpb25zID0gaW5qZWN0KEhhbHZvUm91dGVUcmFuc2l0aW9ucyk7XG5cbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy50cmFuc2l0aW9ucy5hdHRhY2godGhpcy5lbC5uYXRpdmVFbGVtZW50LCB0aGlzLnRyYW5zaXRpb25EZXB0aCwgdGhpcy50cmFuc2l0aW9uQ2FyZHMpO1xuICB9XG5cbiAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgdGhpcy50cmFuc2l0aW9ucy5kZXRhY2godGhpcy5lbC5uYXRpdmVFbGVtZW50KTtcbiAgfVxufVxuXG4vKiogSG9sZHMgYSByb3V0ZSdzIHBhZ2Ugb24gc2NyZWVuIHdoaWxlIEhhbHZvIHBsYXlzIGl0cyBleGl0IGFuaW1hdGlvbiAo4omkIDQwMG1zKS4gKi9cbmV4cG9ydCBjb25zdCBoYWx2b0xlYXZlR3VhcmQ6IENhbkRlYWN0aXZhdGVGbjx1bmtub3duPiA9IChfY29tcG9uZW50LCBfcm91dGUsIGN1cnJlbnQsIG5leHQpID0+XG4gIGluamVjdChIYWx2b1JvdXRlVHJhbnNpdGlvbnMpLmxlYXZlKGN1cnJlbnQudXJsLCBuZXh0LnVybCk7XG5cbi8qKlxuICogQWRkcyBgaGFsdm9MZWF2ZUd1YXJkYCB0byBldmVyeSByb3V0ZSB0aGF0IHJlbmRlcnMgYSBjb21wb25lbnQsIHJlY3Vyc2l2ZWx5LlxuICpcbiAqICAgcHJvdmlkZVJvdXRlcih3aXRoSGFsdm9UcmFuc2l0aW9ucyhyb3V0ZXMpKVxuICpcbiAqIFdyYXAgbGF6aWx5IGxvYWRlZCBjaGlsZCByb3V0ZSBhcnJheXMgKGBsb2FkQ2hpbGRyZW5gKSB0aGUgc2FtZSB3YXkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB3aXRoSGFsdm9UcmFuc2l0aW9ucyhyb3V0ZXM6IFJvdXRlcyk6IFJvdXRlcyB7XG4gIHJldHVybiByb3V0ZXMubWFwKChyKSA9PiB7XG4gICAgY29uc3Qgb3V0OiBSb3V0ZSA9IHsgLi4uciB9O1xuICAgIGlmIChyLmNvbXBvbmVudCB8fCByLmxvYWRDb21wb25lbnQpIG91dC5jYW5EZWFjdGl2YXRlID0gWy4uLihyLmNhbkRlYWN0aXZhdGUgPz8gW10pLCBoYWx2b0xlYXZlR3VhcmRdO1xuICAgIGlmIChyLmNoaWxkcmVuKSBvdXQuY2hpbGRyZW4gPSB3aXRoSGFsdm9UcmFuc2l0aW9ucyhyLmNoaWxkcmVuKTtcbiAgICByZXR1cm4gb3V0O1xuICB9KTtcbn1cbiJdfQ==