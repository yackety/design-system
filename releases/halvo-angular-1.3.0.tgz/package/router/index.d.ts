/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@halvo/angular/router" />
export * from './public-api';
