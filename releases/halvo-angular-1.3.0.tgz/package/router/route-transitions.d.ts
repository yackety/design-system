import { OnDestroy, OnInit } from '@angular/core';
import { CanDeactivateFn, Routes } from '@angular/router';
import * as i0 from "@angular/core";
/**
 * Runs Halvo's page swap between routes: the old page's cards sink and the page slides out,
 * then the new page slides in from the side it comes from and its cards rise.
 * Set up with `HalvoRouteTransitionDirective` on the element around `<router-outlet>`, and
 * `withHalvoTransitions(routes)` in `provideRouter` for the exit half.
 */
export declare class HalvoRouteTransitions {
    private readonly halvo;
    private readonly router;
    private readonly injector;
    private container;
    private depth;
    private cards;
    private sub?;
    private direction;
    private from;
    private leaving;
    /** Called by the directive. */
    attach(el: HTMLElement, depth: number, cards: boolean): void;
    /** Called by the directive. */
    detach(el: HTMLElement): void;
    /**
     * Plays the exit animation when the page (the first `transitionDepth` URL segments) changes.
     * Used by `halvoLeaveGuard`; resolves true when it's done (at most 400ms).
     */
    leave(fromUrl: string, toUrl: string): Promise<boolean> | boolean;
    private enterAfterRender;
    /** The page a URL belongs to: its first `depth` path segments. */
    private key;
    private dirBetween;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoRouteTransitions, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HalvoRouteTransitions>;
}
/**
 * Marks the element that holds `<router-outlet>` as the page container for Halvo's page swap.
 * The new page always slides in and its cards rise; add `withHalvoTransitions(routes)` for the exit half.
 *
 *   <main halvoRouteTransition><router-outlet /></main>
 */
export declare class HalvoRouteTransitionDirective implements OnInit, OnDestroy {
    /** How many URL segments name a page (default 1: /rooms/living → /rooms/kitchen is not a page change). */
    transitionDepth: number;
    /** Let the transition rise the new page's cards (set false if pages run halvoMotion themselves). */
    transitionCards: boolean;
    private readonly el;
    private readonly transitions;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoRouteTransitionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoRouteTransitionDirective, "[halvoRouteTransition]", never, { "transitionDepth": { "alias": "transitionDepth"; "required": false; }; "transitionCards": { "alias": "transitionCards"; "required": false; }; }, {}, never, never, true, never>;
}
/** Holds a route's page on screen while Halvo plays its exit animation (≤ 400ms). */
export declare const halvoLeaveGuard: CanDeactivateFn<unknown>;
/**
 * Adds `halvoLeaveGuard` to every route that renders a component, recursively.
 *
 *   provideRouter(withHalvoTransitions(routes))
 *
 * Wrap lazily loaded child route arrays (`loadChildren`) the same way.
 */
export declare function withHalvoTransitions(routes: Routes): Routes;
