import * as i0 from '@angular/core';
import { inject, NgZone, PLATFORM_ID, Injectable, EventEmitter, ElementRef, forwardRef, Output, Input, Directive } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgControl } from '@angular/forms';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { Subscription } from 'rxjs';

/**
 * Typed access to `window.Halvo`. Client-rendered apps only: SSR is not supported.
 * Load `node_modules/@halvo/design-system/dist/halvo.js` through `"scripts"` in angular.json.
 */
class HalvoService {
    constructor() {
        this.zone = inject(NgZone);
        this.document = inject(DOCUMENT);
        /** False during server-side rendering: every Halvo call is skipped there. */
        this.isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
        this.warned = false;
    }
    /** `window.Halvo`, or null on the server or when halvo.js is not loaded. */
    get halvo() {
        if (!this.isBrowser)
            return null;
        const h = globalThis.Halvo ?? null;
        if (!h && !this.warned) {
            this.warned = true;
            console.warn('[halvo] window.Halvo is missing. Add "node_modules/@halvo/design-system/dist/halvo.js" to "scripts" in angular.json.');
        }
        return h;
    }
    get motion() {
        return this.halvo?.motion ?? null;
    }
    get ui() {
        return this.halvo?.ui ?? null;
    }
    /** The design-system version the page is running, e.g. "1.1.0". */
    get version() {
        return this.halvo?.version ?? null;
    }
    /**
     * Runs Halvo work outside Angular's zone, so animation frames don't trigger change detection.
     * Returns undefined on the server or when halvo.js is missing.
     */
    run(fn) {
        const h = this.halvo;
        return h ? this.zone.runOutsideAngular(() => fn(h)) : undefined;
    }
    /** The current theme, read from `<html data-theme>`. */
    get theme() {
        return this.document.documentElement.dataset['theme'] === 'light' ? 'light' : 'dark';
    }
    /** Switches theme with Halvo's circle wipe from `from` (e.g. the theme button). */
    setTheme(theme, from) {
        const apply = () => {
            this.document.documentElement.dataset['theme'] = theme;
        };
        const p = this.run((h) => h.motion.themeSwap(from ?? null, apply));
        if (p)
            return p;
        apply();
        return Promise.resolve();
    }
    toggleTheme(from) {
        return this.setTheme(this.theme === 'dark' ? 'light' : 'dark', from);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Halvo's thermostat dial on an empty element. Two-way bind the set point with [(value)],
 * or use it as a form control (formControlName / ngModel).
 *
 *   <div halvoDial [(value)]="target" [indoor]="21" [mode]="mode" [on]="heating"></div>
 *   <div halvoDial formControlName="target" class="dial--md"></div>
 */
class HalvoDialDirective {
    constructor() {
        /** The set point (°C). */
        this.value = 21.5;
        /** The measured indoor temperature, shown as a marker on the ring. */
        this.indoor = 21;
        this.mode = 'heat';
        /** Off greys the ticks and shows "Off". */
        this.on = true;
        /** Range and step are read once, when the dial is created. */
        this.min = 10;
        this.max = 30;
        this.step = 0.5;
        /** Show the round − / + buttons. Read once. */
        this.controls = true;
        this.label = 'Set temperature';
        /** Emits the new set point whenever the person turns the dial or presses − / +. */
        this.valueChange = new EventEmitter();
        this.el = inject(ElementRef);
        this.halvo = inject(HalvoService);
        this.zone = inject(NgZone);
        this.applying = false;
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    ngAfterViewInit() {
        this.handle = this.halvo.run((h) => h.ui.dial(this.el.nativeElement, {
            value: this.value,
            indoor: this.indoor,
            mode: this.mode,
            on: this.on,
            min: this.min,
            max: this.max,
            step: this.step,
            controls: this.controls,
            label: this.label,
            onChange: (v) => {
                if (this.applying)
                    return;
                this.zone.run(() => {
                    this.value = v;
                    this.valueChange.emit(v);
                    this.onChange(v);
                    this.onTouched();
                });
            },
        }));
    }
    ngOnChanges(changes) {
        const h = this.handle;
        if (!h)
            return;
        this.zone.runOutsideAngular(() => {
            if (changes['indoor'])
                h.setIndoor(this.indoor);
            if (changes['mode'])
                h.setMode(this.mode);
            if (changes['on'])
                h.setOn(this.on);
        });
        if (changes['value'] && h.value !== this.value)
            this.apply(this.value);
    }
    /** Replays the intro sweep. */
    replay() {
        this.zone.runOutsideAngular(() => this.handle?.replay());
    }
    writeValue(v) {
        if (v === null || v === undefined || v === '' || isNaN(Number(v)))
            return;
        this.value = Number(v);
        if (this.handle && this.handle.value !== this.value)
            this.apply(this.value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) {
        const el = this.el.nativeElement;
        el.classList.toggle('is-disabled', disabled);
        el.style.pointerEvents = disabled ? 'none' : '';
        el.style.opacity = disabled ? '0.45' : '';
    }
    apply(v) {
        const h = this.handle;
        if (!h)
            return;
        this.applying = true;
        try {
            this.zone.runOutsideAngular(() => h.set(v));
        }
        finally {
            this.applying = false;
        }
    }
    ngOnDestroy() {
        this.handle = undefined;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoDialDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoDialDirective, isStandalone: true, selector: "[halvoDial]", inputs: { value: "value", indoor: "indoor", mode: "mode", on: "on", min: "min", max: "max", step: "step", controls: "controls", label: "label" }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => HalvoDialDirective), multi: true }], exportAs: ["halvoDial"], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoDialDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoDial]',
                    standalone: true,
                    exportAs: 'halvoDial',
                    providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => HalvoDialDirective), multi: true }],
                }]
        }], propDecorators: { value: [{
                type: Input
            }], indoor: [{
                type: Input
            }], mode: [{
                type: Input
            }], on: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], controls: [{
                type: Input
            }], label: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

/**
 * Plays one of Halvo's entrance moves once, after the element first renders.
 * List moves (rise, slide, deal, pop, grow, grid) stagger the element's children;
 * `split` animates a heading's letters; `draw` traces the SVG strokes inside.
 *
 *   <div class="kpis" halvoMotion="rise">…cards…</div>
 *   <h1 halvoMotion="split">Good evening, Amara</h1>
 *   <div class="heat" halvoMotion="grid" motionTargets=".heat__cell i" [motionCols]="12"></div>
 */
class HalvoMotionDirective {
    constructor() {
        /** Seconds before the move starts. */
        this.motionDelay = 0;
        /** Columns, for `grid`. */
        this.motionCols = 1;
        this.el = inject(ElementRef);
        this.halvo = inject(HalvoService);
    }
    ngAfterViewInit() {
        this.play();
    }
    /** Plays the move again. */
    play() {
        this.halvo.run(({ motion }) => {
            const host = this.el.nativeElement;
            const pick = (fallback) => (this.motionTargets ? Array.from(host.querySelectorAll(this.motionTargets)) : fallback);
            const kids = pick(Array.from(host.children));
            const opts = { delay: this.motionDelay, ...(this.motionStagger !== undefined ? { stagger: this.motionStagger } : {}) };
            switch (this.halvoMotion) {
                case 'rise': return motion.rise(kids, opts);
                case 'slide': return motion.slide(kids, opts);
                case 'deal': return motion.deal(kids, opts);
                case 'pop': return motion.pop(kids, opts);
                case 'grow': return motion.grow(kids, opts);
                case 'grow-x': return motion.grow(kids, { ...opts, axis: 'x' });
                case 'grid': return motion.gridPop(kids, this.motionCols, { delay: this.motionDelay });
                case 'split': return motion.splitText(this.motionTargets ? host.querySelector(this.motionTargets) : host, { delay: this.motionDelay });
                case 'draw': return motion.draw(pick(host instanceof SVGGeometryElement ? [host] : Array.from(host.querySelectorAll('path, line, polyline, circle'))), { delay: this.motionDelay });
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoMotionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoMotionDirective, isStandalone: true, selector: "[halvoMotion]", inputs: { halvoMotion: "halvoMotion", motionTargets: "motionTargets", motionDelay: "motionDelay", motionStagger: "motionStagger", motionCols: "motionCols" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoMotionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoMotion]',
                    standalone: true,
                }]
        }], propDecorators: { halvoMotion: [{
                type: Input,
                args: [{ required: true }]
            }], motionTargets: [{
                type: Input
            }], motionDelay: [{
                type: Input
            }], motionStagger: [{
                type: Input
            }], motionCols: [{
                type: Input
            }] } });
/**
 * Counts a number up to its value (1.2s) and again from the old value whenever it changes.
 *
 *   <span [halvoCount]="watts" [countFormat]="formatWatts" countFlash></span>
 */
class HalvoCountDirective {
    constructor() {
        /** Start value for the first count (default 0). */
        this.countFrom = 0;
        /** Flash the value in accent when it changes after the first count. */
        this.countFlash = false;
        this.el = inject(ElementRef);
        this.halvo = inject(HalvoService);
        this.first = true;
    }
    ngOnChanges(changes) {
        if (!changes['halvoCount'])
            return;
        const value = Number(this.halvoCount);
        const el = this.el.nativeElement;
        const format = this.countFormat;
        const ran = this.halvo.run(({ motion }) => {
            const opts = { duration: this.countDuration, ...(this.first ? { from: this.countFrom } : {}) };
            void motion.countTo(el, value, format, opts);
            if (!this.first && this.countFlash !== false)
                void motion.flash(el);
        });
        if (ran === undefined)
            el.textContent = format ? format(value) : String(value); // server render
        this.first = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoCountDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoCountDirective, isStandalone: true, selector: "[halvoCount]", inputs: { halvoCount: "halvoCount", countFormat: "countFormat", countDuration: "countDuration", countFrom: "countFrom", countFlash: "countFlash" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoCountDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoCount]',
                    standalone: true,
                }]
        }], propDecorators: { halvoCount: [{
                type: Input,
                args: [{ required: true }]
            }], countFormat: [{
                type: Input
            }], countDuration: [{
                type: Input
            }], countFrom: [{
                type: Input
            }], countFlash: [{
                type: Input
            }] } });
/** Makes the element follow the pointer a little (use on the one primary action). */
class HalvoMagneticDirective {
    constructor() {
        this.el = inject(ElementRef);
        this.halvo = inject(HalvoService);
    }
    ngAfterViewInit() {
        this.halvo.run(({ motion }) => motion.magnetic(this.el.nativeElement.parentElement ?? undefined));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoMagneticDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoMagneticDirective, isStandalone: true, selector: "[halvoMagnetic]", host: { classAttribute: "magnetic" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoMagneticDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoMagnetic]',
                    standalone: true,
                    host: { class: 'magnetic' },
                }]
        }] });
/** Lifts a tile 4px on hover. */
class HalvoLiftDirective {
    constructor() {
        this.el = inject(ElementRef);
        this.halvo = inject(HalvoService);
    }
    ngAfterViewInit() {
        this.halvo.run(({ motion }) => motion.lift(this.el.nativeElement.parentElement ?? undefined));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoLiftDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoLiftDirective, isStandalone: true, selector: "[halvoLift]", host: { attributes: { "data-lift": "" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoLiftDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoLift]',
                    standalone: true,
                    host: { 'data-lift': '' },
                }]
        }] });

const INDICATORS = '.tabs__line, .seg__thumb, .tabbar__pill, .snav__pill';
const RADII = { tabs__line: 12, seg__thumb: 10, tabbar__pill: 18, snav__pill: 14 };
const ACTIVE = '[aria-current="page"], [aria-current="true"], [aria-pressed="true"], [aria-selected="true"]';
/**
 * Slides Halvo's selection pill (tabs, segmented control, side nav, tab bar) to the active item.
 * Put it on the container that holds the indicator; mark the active item with aria-current /
 * aria-pressed / aria-selected (routerLinkActive: `ariaCurrentWhenActive="page"`).
 *
 *   <nav class="tabs" halvoPill>
 *     <span class="tabs__line"></span>
 *     <a routerLink="living" routerLinkActive ariaCurrentWhenActive="page">Living room</a>
 *   </nav>
 */
class HalvoPillDirective {
    constructor() {
        /** Optional CSS selector for the active item (defaults to the aria-current/pressed/selected item). */
        this.halvoPill = '';
        this.el = inject(ElementRef);
        this.halvo = inject(HalvoService);
        this.indicator = null;
        this.frame = 0;
    }
    ngAfterViewInit() {
        this.halvo.run(() => {
            const host = this.el.nativeElement;
            this.indicator = host.querySelector(this.pillIndicator || INDICATORS);
            if (!this.indicator) {
                console.warn('[halvo] halvoPill: no indicator element (.tabs__line, .seg__thumb, .tabbar__pill or .snav__pill) inside', host);
                return;
            }
            this.frame = requestAnimationFrame(() => this.move(false));
            this.observer = new MutationObserver(() => this.move(true));
            this.observer.observe(host, {
                subtree: true,
                childList: true,
                attributes: true,
                attributeFilter: ['aria-current', 'aria-pressed', 'aria-selected'],
            });
        });
    }
    /** Re-measures and moves the pill (e.g. after the container was hidden). */
    update(animate = true) {
        this.halvo.run(() => this.move(animate));
    }
    move(animate) {
        const ind = this.indicator;
        const motion = this.halvo.motion;
        if (!ind || !motion)
            return;
        const target = Array.from(this.el.nativeElement.querySelectorAll(this.halvoPill || ACTIVE)).find((n) => n !== ind) ?? null;
        if (!target) {
            ind.style.opacity = '0';
            return;
        }
        const cls = Object.keys(RADII).find((c) => ind.classList.contains(c));
        void motion.pill(ind, target, { radius: this.pillRadius ?? (cls ? RADII[cls] : 13), animate });
    }
    ngOnDestroy() {
        cancelAnimationFrame(this.frame);
        this.observer?.disconnect();
        const ro = this.indicator?.__ro;
        ro?.disconnect();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoPillDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoPillDirective, isStandalone: true, selector: "[halvoPill]", inputs: { halvoPill: "halvoPill", pillIndicator: "pillIndicator", pillRadius: "pillRadius" }, exportAs: ["halvoPill"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoPillDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoPill]',
                    standalone: true,
                    exportAs: 'halvoPill',
                }]
        }], propDecorators: { halvoPill: [{
                type: Input
            }], pillIndicator: [{
                type: Input
            }], pillRadius: [{
                type: Input
            }] } });

/**
 * Turns a native `<select>` into Halvo's glass listbox.
 *
 *   <select halvoSelect formControlName="room">
 *     @for (r of rooms; track r.id) { <option [value]="r.id">{{ r.name }}</option> }
 *   </select>
 *
 * Works with formControl / formControlName / ngModel (Angular's own select accessor keeps
 * handling the value), re-reads options when they change, follows `disabled`, and removes
 * the listbox when the element is destroyed. Add class `select--sm` for the 34px size.
 */
class HalvoSelectDirective {
    constructor() {
        this.el = inject(ElementRef);
        this.halvo = inject(HalvoService);
        this.zone = inject(NgZone);
        this.control = inject(NgControl, { optional: true, self: true });
        this.handle = null;
        this.subs = new Subscription();
        this.queued = false;
    }
    ngAfterViewInit() {
        const ui = this.halvo.ui;
        if (!ui)
            return;
        const select = this.el.nativeElement;
        select.classList.add('input');
        this.handle = ui.select(select);
        this.zone.runOutsideAngular(() => {
            this.observer = new MutationObserver(() => this.refreshSoon());
            this.observer.observe(select, {
                childList: true,
                subtree: true,
                characterData: true,
                attributes: true,
                attributeFilter: ['disabled', 'label', 'value', 'hidden'],
            });
        });
        if (this.control?.valueChanges)
            this.subs.add(this.control.valueChanges.subscribe(() => this.refreshSoon()));
        if (this.control?.statusChanges)
            this.subs.add(this.control.statusChanges.subscribe(() => this.refreshSoon()));
        this.refreshSoon(); // ngModel writes its first value a tick after init
    }
    /** Re-reads options, value and disabled state. Call it after changing them outside Angular. */
    refresh() {
        this.handle?.refresh();
    }
    open() {
        this.handle?.open();
    }
    close() {
        this.handle?.close();
    }
    refreshSoon() {
        if (this.queued)
            return;
        this.queued = true;
        queueMicrotask(() => {
            this.queued = false;
            this.handle?.refresh();
        });
    }
    ngOnDestroy() {
        this.observer?.disconnect();
        this.subs.unsubscribe();
        const handle = this.handle;
        if (!handle)
            return;
        handle.close();
        const wrap = handle.wrap;
        const select = this.el.nativeElement;
        // put the <select> back where Angular left it, or drop the listbox if Angular already removed it
        if (wrap.isConnected) {
            if (wrap.contains(select))
                wrap.replaceWith(select);
            else
                wrap.remove();
        }
        this.handle = null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoSelectDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoSelectDirective, isStandalone: true, selector: "select[halvoSelect]", exportAs: ["halvoSelect"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoSelectDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'select[halvoSelect]',
                    standalone: true,
                    exportAs: 'halvoSelect',
                }]
        }] });

/*
 * @halvo/angular — Angular bindings for the Halvo design system.
 * Needs @halvo/design-system: dist/halvo.css in "styles" and dist/halvo.js in "scripts" (angular.json).
 */
/** Every Halvo directive, for a standalone component's `imports`. */
const HALVO_DIRECTIVES = [
    HalvoSelectDirective,
    HalvoPillDirective,
    HalvoDialDirective,
    HalvoMotionDirective,
    HalvoCountDirective,
    HalvoMagneticDirective,
    HalvoLiftDirective,
];

/**
 * Generated bundle index. Do not edit.
 */

export { HALVO_DIRECTIVES, HalvoCountDirective, HalvoDialDirective, HalvoLiftDirective, HalvoMagneticDirective, HalvoMotionDirective, HalvoPillDirective, HalvoSelectDirective, HalvoService };
//# sourceMappingURL=halvo-angular.mjs.map
