import * as i0 from '@angular/core';
import { inject, EnvironmentInjector, afterNextRender, Injectable, ElementRef, Input, Directive } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { HalvoService } from '@halvo/angular';

/** Links whose order defines "forward" and "back" between pages. */
const NAV_LINKS = '.snav a[href], .tabbar a[href], .side a[href], nav a[href]';
/** Longest a page may wait for its exit animation before the navigation goes on anyway. */
const MAX_WAIT_MS = 400;
/**
 * Runs Halvo's page swap between routes: the old page's cards sink and the page slides out,
 * then the new page slides in from the side it comes from and its cards rise.
 * Set up with `HalvoRouteTransitionDirective` on the element around `<router-outlet>`, and
 * `withHalvoTransitions(routes)` in `provideRouter` for the exit half.
 */
class HalvoRouteTransitions {
    constructor() {
        this.halvo = inject(HalvoService);
        this.router = inject(Router);
        this.injector = inject(EnvironmentInjector);
        this.container = null;
        this.depth = 1;
        this.cards = true;
        this.direction = 1;
        this.from = '';
        this.leaving = null;
    }
    /** Called by the directive. */
    attach(el, depth, cards) {
        this.container = el;
        this.depth = Math.max(1, depth);
        this.cards = cards;
        if (this.sub || !this.halvo.isBrowser)
            return;
        this.sub = this.router.events.subscribe((e) => {
            if (e instanceof NavigationStart) {
                this.from = this.router.url;
                this.direction = this.dirBetween(this.from, e.url, e.navigationTrigger === 'popstate');
            }
            else if (e instanceof NavigationEnd) {
                const changed = this.key(this.from) !== this.key(e.urlAfterRedirects);
                const left = this.leaving !== null;
                this.leaving = null;
                if (changed || left)
                    this.enterAfterRender();
            }
            else if (e instanceof NavigationCancel || e instanceof NavigationError) {
                if (this.leaving && this.container) {
                    const c = this.container;
                    this.halvo.run((h) => h.motion.pageReset(c));
                }
                this.leaving = null;
            }
        });
    }
    /** Called by the directive. */
    detach(el) {
        if (this.container === el)
            this.container = null;
    }
    /**
     * Plays the exit animation when the page (the first `transitionDepth` URL segments) changes.
     * Used by `halvoLeaveGuard`; resolves true when it's done (at most 400ms).
     */
    leave(fromUrl, toUrl) {
        const c = this.container;
        if (!c || !this.halvo.motion || this.key(fromUrl) === this.key(toUrl))
            return true;
        if (this.leaving?.url === toUrl)
            return this.leaving.done;
        const dir = this.direction;
        const run = this.halvo.run((h) => h.motion.pageOut(c, { direction: dir })) ?? Promise.resolve();
        const done = Promise.race([run, new Promise((r) => setTimeout(r, MAX_WAIT_MS))]).then(() => true);
        this.leaving = { url: toUrl, done };
        return done;
    }
    enterAfterRender() {
        const c = this.container;
        if (!c)
            return;
        const dir = this.direction;
        const cards = this.cards;
        afterNextRender(() => this.halvo.run((h) => h.motion.pageIn(c, { direction: dir, cards })), { injector: this.injector });
    }
    /** The page a URL belongs to: its first `depth` path segments. */
    key(url) {
        return url.split(/[?#(]/)[0].split('/').filter(Boolean).slice(0, this.depth).join('/');
    }
    dirBetween(from, to, popstate) {
        const keys = [];
        document.querySelectorAll(NAV_LINKS).forEach((a) => {
            const k = this.key(new URL(a.href, document.baseURI).pathname.replace(new URL(document.baseURI).pathname, '/'));
            if (!keys.includes(k))
                keys.push(k);
        });
        const a = keys.indexOf(this.key(from));
        const b = keys.indexOf(this.key(to));
        if (a > -1 && b > -1 && a !== b)
            return b > a ? 1 : -1;
        return popstate ? -1 : 1;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitions, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitions, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitions, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Marks the element that holds `<router-outlet>` as the page container for Halvo's page swap.
 * The new page always slides in and its cards rise; add `withHalvoTransitions(routes)` for the exit half.
 *
 *   <main halvoRouteTransition><router-outlet /></main>
 */
class HalvoRouteTransitionDirective {
    constructor() {
        /** How many URL segments name a page (default 1: /rooms/living → /rooms/kitchen is not a page change). */
        this.transitionDepth = 1;
        /** Let the transition rise the new page's cards (set false if pages run halvoMotion themselves). */
        this.transitionCards = true;
        this.el = inject(ElementRef);
        this.transitions = inject(HalvoRouteTransitions);
    }
    ngOnInit() {
        this.transitions.attach(this.el.nativeElement, this.transitionDepth, this.transitionCards);
    }
    ngOnDestroy() {
        this.transitions.detach(this.el.nativeElement);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: HalvoRouteTransitionDirective, isStandalone: true, selector: "[halvoRouteTransition]", inputs: { transitionDepth: "transitionDepth", transitionCards: "transitionCards" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HalvoRouteTransitionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[halvoRouteTransition]',
                    standalone: true,
                }]
        }], propDecorators: { transitionDepth: [{
                type: Input
            }], transitionCards: [{
                type: Input
            }] } });
/** Holds a route's page on screen while Halvo plays its exit animation (≤ 400ms). */
const halvoLeaveGuard = (_component, _route, current, next) => inject(HalvoRouteTransitions).leave(current.url, next.url);
/**
 * Adds `halvoLeaveGuard` to every route that renders a component, recursively.
 *
 *   provideRouter(withHalvoTransitions(routes))
 *
 * Wrap lazily loaded child route arrays (`loadChildren`) the same way.
 */
function withHalvoTransitions(routes) {
    return routes.map((r) => {
        const out = { ...r };
        if (r.component || r.loadComponent)
            out.canDeactivate = [...(r.canDeactivate ?? []), halvoLeaveGuard];
        if (r.children)
            out.children = withHalvoTransitions(r.children);
        return out;
    });
}

/*
 * @halvo/angular/router — Halvo's page swap between routes. Needs @angular/router.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { HalvoRouteTransitionDirective, HalvoRouteTransitions, halvoLeaveGuard, withHalvoTransitions };
//# sourceMappingURL=halvo-angular-router.mjs.map
