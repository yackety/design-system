/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@halvo/angular" />
export * from './public-api';
