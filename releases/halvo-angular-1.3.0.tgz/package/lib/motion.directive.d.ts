import { AfterViewInit, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export type HalvoMotionName = 'rise' | 'slide' | 'deal' | 'pop' | 'grow' | 'grow-x' | 'draw' | 'split' | 'grid';
/**
 * Plays one of Halvo's entrance moves once, after the element first renders.
 * List moves (rise, slide, deal, pop, grow, grid) stagger the element's children;
 * `split` animates a heading's letters; `draw` traces the SVG strokes inside.
 *
 *   <div class="kpis" halvoMotion="rise">…cards…</div>
 *   <h1 halvoMotion="split">Good evening, Amara</h1>
 *   <div class="heat" halvoMotion="grid" motionTargets=".heat__cell i" [motionCols]="12"></div>
 */
export declare class HalvoMotionDirective implements AfterViewInit {
    halvoMotion: HalvoMotionName;
    /** CSS selector of what to animate inside the element (default: its children, or the element itself for split/draw). */
    motionTargets?: string;
    /** Seconds before the move starts. */
    motionDelay: number;
    /** Seconds between items (each move has its own default). */
    motionStagger?: number;
    /** Columns, for `grid`. */
    motionCols: number;
    private readonly el;
    private readonly halvo;
    ngAfterViewInit(): void;
    /** Plays the move again. */
    play(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoMotionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoMotionDirective, "[halvoMotion]", never, { "halvoMotion": { "alias": "halvoMotion"; "required": true; }; "motionTargets": { "alias": "motionTargets"; "required": false; }; "motionDelay": { "alias": "motionDelay"; "required": false; }; "motionStagger": { "alias": "motionStagger"; "required": false; }; "motionCols": { "alias": "motionCols"; "required": false; }; }, {}, never, never, true, never>;
}
/**
 * Counts a number up to its value (1.2s) and again from the old value whenever it changes.
 *
 *   <span [halvoCount]="watts" [countFormat]="formatWatts" countFlash></span>
 */
export declare class HalvoCountDirective implements OnChanges {
    halvoCount: number;
    /** Formats the running value (default: rounded, with thousands separators). */
    countFormat?: (v: number) => string;
    /** Seconds (default 1.2). */
    countDuration?: number;
    /** Start value for the first count (default 0). */
    countFrom: number;
    /** Flash the value in accent when it changes after the first count. */
    countFlash: boolean | '';
    private readonly el;
    private readonly halvo;
    private first;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoCountDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoCountDirective, "[halvoCount]", never, { "halvoCount": { "alias": "halvoCount"; "required": true; }; "countFormat": { "alias": "countFormat"; "required": false; }; "countDuration": { "alias": "countDuration"; "required": false; }; "countFrom": { "alias": "countFrom"; "required": false; }; "countFlash": { "alias": "countFlash"; "required": false; }; }, {}, never, never, true, never>;
}
/** Makes the element follow the pointer a little (use on the one primary action). */
export declare class HalvoMagneticDirective implements AfterViewInit {
    private readonly el;
    private readonly halvo;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoMagneticDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoMagneticDirective, "[halvoMagnetic]", never, {}, {}, never, never, true, never>;
}
/** Lifts a tile 4px on hover. */
export declare class HalvoLiftDirective implements AfterViewInit {
    private readonly el;
    private readonly halvo;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoLiftDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoLiftDirective, "[halvoLift]", never, {}, {}, never, never, true, never>;
}
