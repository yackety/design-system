import { AfterViewInit, EventEmitter, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export type HalvoDialMode = 'heat' | 'cool' | 'eco' | 'auto';
/**
 * Halvo's thermostat dial on an empty element. Two-way bind the set point with [(value)],
 * or use it as a form control (formControlName / ngModel).
 *
 *   <div halvoDial [(value)]="target" [indoor]="21" [mode]="mode" [on]="heating"></div>
 *   <div halvoDial formControlName="target" class="dial--md"></div>
 */
export declare class HalvoDialDirective implements AfterViewInit, OnChanges, OnDestroy, ControlValueAccessor {
    /** The set point (°C). */
    value: number;
    /** The measured indoor temperature, shown as a marker on the ring. */
    indoor: number;
    mode: HalvoDialMode;
    /** Off greys the ticks and shows "Off". */
    on: boolean;
    /** Range and step are read once, when the dial is created. */
    min: number;
    max: number;
    step: number;
    /** Show the round − / + buttons. Read once. */
    controls: boolean;
    label: string;
    /** Emits the new set point whenever the person turns the dial or presses − / +. */
    readonly valueChange: EventEmitter<number>;
    private readonly el;
    private readonly halvo;
    private readonly zone;
    private handle?;
    private applying;
    private onChange;
    private onTouched;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /** Replays the intro sweep. */
    replay(): void;
    writeValue(v: unknown): void;
    registerOnChange(fn: (v: number) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    private apply;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoDialDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoDialDirective, "[halvoDial]", ["halvoDial"], { "value": { "alias": "value"; "required": false; }; "indoor": { "alias": "indoor"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "on": { "alias": "on"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "controls": { "alias": "controls"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
