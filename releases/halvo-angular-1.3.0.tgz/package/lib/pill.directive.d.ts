import { AfterViewInit, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Slides Halvo's selection pill (tabs, segmented control, side nav, tab bar) to the active item.
 * Put it on the container that holds the indicator; mark the active item with aria-current /
 * aria-pressed / aria-selected (routerLinkActive: `ariaCurrentWhenActive="page"`).
 *
 *   <nav class="tabs" halvoPill>
 *     <span class="tabs__line"></span>
 *     <a routerLink="living" routerLinkActive ariaCurrentWhenActive="page">Living room</a>
 *   </nav>
 */
export declare class HalvoPillDirective implements AfterViewInit, OnDestroy {
    /** Optional CSS selector for the active item (defaults to the aria-current/pressed/selected item). */
    halvoPill: string | '';
    /** Optional CSS selector for the indicator (defaults to the Halvo indicator classes). */
    pillIndicator?: string;
    /** Corner radius in px (defaults per component: tabs 12, segmented 10, tab bar 18, side nav 14). */
    pillRadius?: number;
    private readonly el;
    private readonly halvo;
    private observer?;
    private indicator;
    private frame;
    ngAfterViewInit(): void;
    /** Re-measures and moves the pill (e.g. after the container was hidden). */
    update(animate?: boolean): void;
    private move;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoPillDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoPillDirective, "[halvoPill]", ["halvoPill"], { "halvoPill": { "alias": "halvoPill"; "required": false; }; "pillIndicator": { "alias": "pillIndicator"; "required": false; }; "pillRadius": { "alias": "pillRadius"; "required": false; }; }, {}, never, never, true, never>;
}
