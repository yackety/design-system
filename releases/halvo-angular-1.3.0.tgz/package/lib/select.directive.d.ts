import { AfterViewInit, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Turns a native `<select>` into Halvo's glass listbox.
 *
 *   <select halvoSelect formControlName="room">
 *     @for (r of rooms; track r.id) { <option [value]="r.id">{{ r.name }}</option> }
 *   </select>
 *
 * Works with formControl / formControlName / ngModel (Angular's own select accessor keeps
 * handling the value), re-reads options when they change, follows `disabled`, and removes
 * the listbox when the element is destroyed. Add class `select--sm` for the 34px size.
 */
export declare class HalvoSelectDirective implements AfterViewInit, OnDestroy {
    private readonly el;
    private readonly halvo;
    private readonly zone;
    private readonly control;
    private handle;
    private observer?;
    private readonly subs;
    private queued;
    ngAfterViewInit(): void;
    /** Re-reads options, value and disabled state. Call it after changing them outside Angular. */
    refresh(): void;
    open(): void;
    close(): void;
    private refreshSoon;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoSelectDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HalvoSelectDirective, "select[halvoSelect]", ["halvoSelect"], {}, {}, never, never, true, never>;
}
