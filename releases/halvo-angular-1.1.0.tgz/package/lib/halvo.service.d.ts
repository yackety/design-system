import type { MotionProps, UiProps } from './halvo-api';
import * as i0 from "@angular/core";
/** The shape of `window.Halvo`, defined by `@halvo/design-system/dist/halvo.js`. */
export interface HalvoGlobal {
    motion: MotionProps;
    ui: UiProps;
    version: string;
}
export type HalvoTheme = 'dark' | 'light';
/**
 * Typed, SSR-safe access to `window.Halvo`.
 * Load `node_modules/@halvo/design-system/dist/halvo.js` through `"scripts"` in angular.json.
 */
export declare class HalvoService {
    private readonly zone;
    private readonly document;
    /** False during server-side rendering: every Halvo call is skipped there. */
    readonly isBrowser: boolean;
    private warned;
    /** `window.Halvo`, or null on the server or when halvo.js is not loaded. */
    get halvo(): HalvoGlobal | null;
    get motion(): MotionProps | null;
    get ui(): UiProps | null;
    /** The design-system version the page is running, e.g. "1.1.0". */
    get version(): string | null;
    /**
     * Runs Halvo work outside Angular's zone, so animation frames don't trigger change detection.
     * Returns undefined on the server or when halvo.js is missing.
     */
    run<T>(fn: (halvo: HalvoGlobal) => T): T | undefined;
    /** The current theme, read from `<html data-theme>`. */
    get theme(): HalvoTheme;
    /** Switches theme with Halvo's circle wipe from `from` (e.g. the theme button). */
    setTheme(theme: HalvoTheme, from?: Element | null): Promise<void>;
    toggleTheme(from?: Element | null): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HalvoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HalvoService>;
}
